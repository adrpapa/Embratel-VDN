<?php
/*
** Constantes de uso geral para as chamadas de API do Elemental
*/
    class ConfigConsts {
        
        const debug = true;
        
        const TEMPLATE_PATH = "/home/fastlane/Embratel/templates";

        const LIVE_CONDUCTOR_URL = "http://201.31.12.4/api/live_events";
        const LIVE_TEMPLATE_STANDARD = 13;
        const LIVE_TEMPLATE_PREMIUM = 13;
        const LIVE_NODE_URL = "rtmp://localhost:1935/";
        
        const DELTA_URL = "10.0.0.21";
        
    }
?>
