#!/usr/bin/env php

<?php    
    require "live.php";

    parse_str(implode('&', array_slice($argv, 1)), $_GET);
    @$id = $_GET['id'];
    @$func = $_GET['func'];
    @$filter = $_GET['filter'];
    @$cmd = $_GET['cmd'];
    
    var_dump($cmd);
    var_dump($func);
    
    if( $cmd == NULL && $func == NULL ) {
        print "usage:\n";
        print "testLive.php func=new\tCria evento Live\n";
        print "testLive.php func=list\tlista todos eventos ativos evento Live\n";
        print "\n\n";
    }
    if( $cmd ){
        LiveEvent::getElementalLive()->postRecord($id, $cmd);
        exit();
    }

    switch( $func ) {
        case 'new':
            $live = LiveEvent::newStandardLiveEvent( $name="Teste de criação via API",
                $clientID="Fregues1",
                $udpPort="5010");
            break;
        case 'del':
            LiveEvent::delete($id);
            break;
        case 'list':
            $events = LiveEvent::getEventList($id, $filter);
            if($id) {
                print($events->asXml());
                printf("%s - %s %s\n",$events->id, $events->name, $events->status);
            } else {
                foreach ( $events->live_event as $event ) {
                    $liveEvent = LiveEvent::liveEventFromXML($event);
                    printf("%s - %s %s\n",$liveEvent->id, $liveEvent->name, $liveEvent->status);
                }
                break;
            }
    }
?>
