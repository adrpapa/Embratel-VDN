<?php
require "live.php";
$ev =  LiveEvent::getStatus(63);
print_r( $ev );

?>


