<?php

require "aps/2/runtime.php";

/**
 * Class Hello
 * @type("http://www.parallels.com/web/hello/1.0")
 * @implements("http://aps-standard.org/types/core/application/1.0")
 */
class Hello extends APS\ResourceBase
{
	
	# Webspace information
	/**
	 * @link("http://aps-standard.org/types/infrastructure/environment/web/1.0")
	 * @allocate(new)
	 * - requirement("in(php,engines)")
	 * - requirement("in(mysql,php.extensions)")
	 * - requirement("default(php.safe_mode,yes)")
	 * @required
	 */
	public $website;

	# Settings
	/** 
	 * @type(string) 
	 * @title("Administrator Name")
	 * @description("Administrator Name")
	 */
	public $admin_name;

	/** 
	 * No additional declaration required when overriding base methods
	 */
	public function provision()
	{

		# Installing Hello config from hello.php.in template. Placeholders in hello.php.in are replaced with their values
		$fSystemHelper = new \APS\FilesConfigurator($this, $this->website);
		$fSystemHelper->writeConfigFile('hello.php.in', $this->website->path.'/'.$this->website->root.'/index.php');
	}
}

?>
