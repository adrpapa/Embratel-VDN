<?php

require "aps/2/runtime.php";

// Definition of type structures

class CPU {
	/**
	 * @type("integer")
	 * @title("Number of CPUs")
	 * @description("Number of CPU cores")
	 */
	public $number;
}

class OS {
	/**
	 * @type("string")
	 * @title("OS Name")
	 * @description("Operating System Name")
	 */
	public $name;

	/**
	 * @type("string")
	 * @title("OS Version")
	 * @description("Operating System version")
	 */
	public $version;
}

class Hardware {
	/**
	 * @type("integer")
	 * @title("RAM Size")
	 * @description("RAM size in GB")
	 */
	public $memory;

	/**
	 * @type("integer")
	 * @title("Disk Space")
	 * @description("Disk space in GB")
	 */
	public $diskspace;

	/**
	 * @type("CPU")
	 * @title("CPU")
	 * @description("Server CPU parameters")
	 */
	public $CPU;
}

class Platform {
	/**
	 * @type("string")
	 * @title("Architecture")
	 * @description("Platform architecture")
	 */
	public $arch;

	/**
	 * @type("OS")
	 * @title("OS Parameters")
	 * @description("Parameters of operating system")
	 */
	public $OS;
}


// Main class
/**
 * @type("http://company.example/app/resmon/vps/1.0")
 * @implements("http://aps-standard.org/types/core/resource/1.0")
 */
class vps extends APS\ResourceBase {
	
	// Relation with the management context
	/**
	 * @link("http://company.example/app/resmon/context/1.0")
	 * @required
	 */
	public $context;

	// VPS properties
	
	/**
	 * @type("string")
	 * @title("name")
	 * @description("Server Name")
	 */
	public $name;
	
	/**
	 * @type("string")
	 * @title("Description")
	 * @description("Server Description")
	 */
	public $description;
	
	/**
	 * @type("string")
	 * @title("state")
	 * @description("Server State")
	 */
	public $state;
	
	// VPS complex properties (structures) - defined as classes above
	
	/**
	 * @type("Hardware")
	 * @title("Hardware")
	 * @description("Server Hardware")
	 */
	public $hardware;
	
	/**
	 * @type("Platform")
	 * @title("Platform")
	 * @description("OS Platform")
	 */
	public $platform;
			
	/**
	 * @type("integer")
	 * @title("CPU actual usage")
	 * @description("CPU cores actual usage")
	 */
	public $cpuActualUsage;

	/**
	 * @type("integer")
	 * @title("RAM actual usage")
	 * @description("RAM space actual usage")
	 */
	public $ramActualUsage;

	/**
	 * @type("integer")
	 * @title("Disk actual usage")
	 * @description("Disk space actual usage")
	 */
	public $diskActualUsage;

	
	## Custom function with the following operations
	 # Update resource usage - for demo, random values are assigned
	 # Update the APS resource with the new resource usage values
	 # Return resource usage values
	/**
	 * Set random values to resource usage and return them back
	 * @verb(GET)
	 * @path("/updateResourceUsage")
	 */
	public function updateResourceUsage () {
		error_log("Updating resource usage in VPS, ID: ".$this->aps->id); // For debugging only.
		$usage = array();

		$this->cpuActualUsage = rand(1,32);
		$usage['cpuActualUsage'] = $this->cpuActualUsage;

		$this->ramActualUsage = rand(100,5000);
		$usage['ramActualUsage'] = $this->ramActualUsage;

		$this->diskActualUsage = rand(1,100);
		$usage['diskActualUsage'] = $this->diskActualUsage;

		## Save resource usage in the APS controller
		$apsc = \APS\Request::getController();
		$apsc->updateResource($this);

		return $usage;
	}
}

