<?php
# It is the context of the subscription, in which a customer can manage its VPSes.
# It must correspond to a tenant created for the subscriber in the remote application system.
require "aps/2/runtime.php";

/**
* Class context
* @type("http://company.example/app/resmon/context/1.0")
* @implements("http://aps-standard.org/types/core/resource/1.0")
*/

class context extends \APS\ResourceBase
{
	
## Strong relation (link) to the application instance
		
	/**
	* @link("http://company.example/app/resmon/cloud/1.0")
	* @required
	*/
	public $cloud;
	
## Weak relation (link) to collection of VPSes
	/**
	 * @link("http://company.example/app/resmon/vps/1.0[]")
	 */
	public $vpses;
	
## Strong relation with the Subscription.
## This way, we allow the service to access the operation resources
## with the limits and usage defined in the subscription.

	/**
	* @link("http://aps-standard.org/types/core/subscription/1.0")
	* @required
	*/
    public $subscription;

## Link to the account type makes account attributes available to the service,
## e.g., the account (subscriber) name, and all its other data.

	/**
	* @link("http://aps-standard.org/types/core/account/1.0")
    	* @required
    	*/
    public $account;

	## Declare subscription-wide resource counters below.
	## The counter values will be defined by the retrieve() function in this class.
	
	/**
	 * @type("http://aps-standard.org/types/core/resource/1.0#Counter")
	 * @description("Total Disk Space Usage")
	 * @unit("gb")
	 */
	public $diskusagetotal;
	
	/**
	 * @type("http://aps-standard.org/types/core/resource/1.0#Counter")
	 * @description("Total CPU usage")
	 * @unit("unit")
	 */
	public $cpuusagetotal;
	
	/**
	 * @type("http://aps-standard.org/types/core/resource/1.0#Counter")
	 * @description("Total Memory usage")
	 * @unit("mb")
	 */
	public $memoryusagetotal;
		
	# This is the method that APS controller will call for getting resource usage from resource counters.
	# The method will collect resource usage by calling each VPS linked with this context.
	public function retrieve() {
		error_log("Fetching resource usage"); //For debugging only, see /var/log/httpd/ssl_error_log.
		## Connect to the APS controller
		$apsc = \APS\Request::getController();
		## Reset the local counters
		$disk = 0;
		$ram = 0;
		$cpu = 0;
		
		## Collect resource usage from all VPSes
		foreach ($this->vpses as $vps) {
			$usage = $apsc->getIo()->sendRequest(\APS\Proto::GET,
					$apsc->getIo()->resourcePath($vps->aps->id, 'updateResourceUsage'));				
			error_log("Fetched resource usage: ".$usage); //For debugging only, see /var/log/httpd/ssl_error_log.
			$usage = json_decode($usage);
			$disk = $disk + $usage->diskActualUsage;
			$ram = $ram + $usage->ramActualUsage;
			$cpu = $cpu + $usage->cpuActualUsage;
		}
		## Update the APS resource counters	
		$this->diskusagetotal->usage = $disk;
		$this->memoryusagetotal->usage = $ram;
		$this->cpuusagetotal->usage = $cpu;
	}    
}
?>
