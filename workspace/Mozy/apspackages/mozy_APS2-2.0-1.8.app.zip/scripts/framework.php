<?php

define('CONFIG_PATH',__DIR__."/configuration");

require_once "vendor/autoload.php";

